export interface procedures{
    pcode:string,
    pcodedesc:string
}