import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import {DatabaseService} from './../database.service';
import {procedures} from './../procedures';
import { Apollo } from "apollo-angular";
import gql from "graphql-tag";
// import { UITKCardModule } from '@uitk/angular';
// import {​​ MatButtonModule }​​ from '@angular/material/button';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

ghostText = 'Ghost';

dataSource:procedures[];
dcode :string;
dcodedesc:string="";
procedures:procedures[];
displayedColumns: string[] = ['pcode', 'pcodedesc'];

  constructor(private db:DatabaseService,private apollo: Apollo) { }

  ngOnInit(): void {
  }
submit(code){


 console.log("code submitted is",code)
  //get request with the value of code and assigning to the dcodedesc.
  this.db.getdescription(code).subscribe(data=>this.dcodedesc=data,error=>console.log(error));

  
  //get request with code and retrieve the procedures and assign to procedures.
  this.db.getprocedures(code).subscribe(data=>this.procedures=data,error=>console.log(error));
  this.dcodedesc="This is the description for above code"
  this.procedures=[
    {pcode:"1",pcodedesc:"This is the long description for the procedures mentioned code 1"},
    {pcode:"2",pcodedesc:"This is the long description for the procedures mentioned code 2"},
    {pcode:"3",pcodedesc:"This is the long description for the procedures mentioned code 3"},
    {pcode:"4",pcodedesc:"This is the long description for the procedures mentioned code 4"},
    {pcode:"5",pcodedesc:"This is the long description for the procedures mentioned code 5"}
  ]
  this.apollo
  .query<any>({
    query: gql`
    query MyQuery {
      icd10(where: {diag_cd: {_eq: "${this.dcode}"}}) {
        full_desc
      }
    }
    
    
    `
  })
  .subscribe(
    ({ data, loading }) => {
      this.dcodedesc=data.icd10[0].full_desc
      console.log("this is the data =>",data);
      console.log("this is the loading =>",loading);
    }
  );
}
}

